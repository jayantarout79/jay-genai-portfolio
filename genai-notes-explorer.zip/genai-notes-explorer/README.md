python3 src/loaders.py data
python3 src/chunker.py data --out index/chunks.jsonl --size 1000 --overlap 200
python3 src/embedder.py build --chunks index/chunks.jsonl --out index/ --model text-embedding-3-small --batch 128
python3 src/embedder.py stats --out index/
python3 src/retriever.py --index index/ \
  --query "What metrics did we optimize in the retail purchase project and why?" --k 5